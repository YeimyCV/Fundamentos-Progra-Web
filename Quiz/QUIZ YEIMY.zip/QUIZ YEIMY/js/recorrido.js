//variables controladoras
var panorama, viewer, container, infospot;

container = document.querySelector('#container_principal');

panorama = new PANOLENS.ImagePanorama('imagenes/gimnasio.jpeg');

//Spot1
var infospot1 = new PANOLENS.Infospot(30, PANOLENS.DataImage.Info);
var infospot1 = new PANOLENS.Infospot(100, 'imagenes/mancuerna.png'); 
infospot1.position.set(321 ,117 , -500);
infospot1.addHoverText('Tenemos el mejor equipo para entrenamiento de fuerza, de acuerdo a diversos gustos y necesidades, desde mancuernas, dumbells, kettlebells hasta máquinas especializadas en distintos grupos musculares.', -60);
infospot1.element.innerHTML = '<div style="background-color: rgba(2, 168, 2, 0.65); color:#fff; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">Tenemos el mejor equipo para entrenamiento de fuerza, de acuerdo a diversos gustos y necesidades, desde mancuernas, dumbells, kettlebells hasta máquinas especializadas en distintos grupos musculares.</div>';
panorama.add(infospot1);

//Spot2
var infospot2 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
var infospot2 = new PANOLENS.Infospot(200, 'imagenes/brazo.png'); 
infospot2.position.set(1000, -100, 1000);
infospot2.addHoverText('Entre nuestra amplia oferta de clases individuales y grupales, puedes encontrar desde yoga, pilates, zumba, hasta crossfit y todos los implementos necesarios para que practiques de forma segura, entretenida y efectiva.', -60);
infospot2.element.innerHTML = '<div style="background-color: rgba(2, 168, 2, 0.65); color:#fff; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">Entre nuestra amplia oferta de clases individuales y grupales, puedes encontrar desde yoga, pilates, zumba, hasta crossfit y todos los implementos necesarios para que practiques de forma segura, entretenida y efectiva.</div>';
panorama.add(infospot2);

//Spot3
var infospot3 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
var infospot3 = new PANOLENS.Infospot(150, 'imagenes/maquinas.png'); 
infospot3.position.set(-500 ,172 , -450);
infospot3.addHoverText('Video motivacional', -60);
infospot3.element.innerHTML = `
    <div class="" style="">
        <iframe width="720" height="480" src="https://www.youtube.com/embed/TFO9hBtLVec"></iframe>        
    </div>
`;
panorama.add(infospot3);

//Spot4
var infospot4 = new PANOLENS.Infospot(200, PANOLENS.DataImage.Info);
var infospot4 = new PANOLENS.Infospot(75, 'imagenes/banos.png');
infospot4.position.set(-501 ,104 , -25);
infospot4.addHoverText('Contamos con baños y duchas espaciosas, para que puedas ejercitarte sin preocuparte por dónde prepararte para otras actividades en el día. Estos espacios son individuales pensando en tu privacidad y comodidad, además contamos con casilleros para que puedas resguardar tus objetos personales y realizar tus rutinas con tranquilidad', -60);
infospot4.element.innerHTML = '<div style="background-color: rgba(2, 168, 2, 0.65); color:#fff; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">Contamos con baños y duchas espaciosas, para que puedas ejercitarte sin preocuparte por dónde prepararte para otras actividades en el día. Estos espacios son individuales pensando en tu privacidad y comodidad, además contamos con casilleros para que puedas resguardar tus objetos personales y realizar tus rutinas con tranquilidad.</div>';
panorama.add(infospot4);

//Spot5
var infospot5 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
var infospot5 = new PANOLENS.Infospot(75, 'imagenes/spinning.png'); 
infospot5.position.set(500 ,80 , -31);

infospot5.addHoverText('Te ofrecemos una zona exclusiva para el entrenamiento cardiovasular con bicicletas de spinning, caminadoras, elipticas y demás.', -60);
infospot5.element.innerHTML = '<div style="background-color: rgba(2, 168, 2, 0.65); color:#fff; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">Te ofrecemos una zona exclusiva para el entrenamiento cardiovasular con bicicletas de spinning, caminadoras, elipticas y demás.</div>';
panorama.add(infospot5);

//Spot6
var infospot6 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
var infospot6 = new PANOLENS.Infospot(75, 'imagenes/musica.png'); 
infospot6.position.set(2 ,114 , 500);
infospot6.addHoverText('Un audio MP3 multimedial...', -60);
infospot6.element.innerHTML = '<div style="color:#000; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;"><audio controls><source src="multimedia/audiovictorius.mp3" type="audio/mpeg"></audio></div>';
panorama.add(infospot6);

//Spot7
var infospot7 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
var infospot7 = new PANOLENS.Infospot(100, 'imagenes/pesa.png'); 
infospot7.position.set(-488 ,-162 , -501);
infospot7.addHoverText('Video motivacional', -60);
infospot7.element.innerHTML = `
    <div class="" style="">
        <iframe width="720" height="480" src="https://www.youtube.com/embed/eaRQF-7hhmo"></iframe>        
    </div>
`;
panorama.add(infospot7);


viewer = new PANOLENS.Viewer({ container: container});

viewer.add(panorama);